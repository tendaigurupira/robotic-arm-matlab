% Simscape Multibody Link
% Version 24.2 (R2024b) 21-Jun-2024

%   Copyright 2007-2024 The MathWorks, Inc.
